/*
 * To change this license header, choose License HeaderesultSet in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CafeManagement;

import java.sql.PreparedStatement;
import java.awt.Image;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.Arrays;


public class admin_m_cart extends javax.swing.JFrame {

    ResultSet rs ;
    Connection conn;
    Statement stmt;
    Object[] row = new Object[10];
    String url = "jdbc:mysql://localhost:3306/cafe";
    String Driver = "com.mysql.cj.jdbc.Driver";
    String password = "mavismon";
    String username = "root";
     PreparedStatement pstmt;
    
    
    public admin_m_cart() {
        initComponents();
        display();
       
     
    }
    
    public void display()
    {
        try {
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT mc.customerid, c.customername, i.itemname, i.itemprice, mc.quantity, mc.totalprice, mc.datetime, mc.tranNo FROM mycart mc JOIN item i ON mc.itemid = i.itemid JOIN customer c ON mc.customerid = c.customerid");
            DefaultTableModel m = (DefaultTableModel) TA.getModel();
            m.setRowCount(0);
            while (rs.next()) {
                    row[0] = rs.getString("customerid");
                    row[1]=rs.getString("customername");
                    row[2] = rs.getString("itemname");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("quantity");
                    row[5] = rs.getString("totalprice");
                    row[6] = rs.getString("datetime");
                    row[7] = rs.getString("tranNo");
                m.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TA = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnsearch = new javax.swing.JButton();
        txtcustomerid = new javax.swing.JTextField();
        txttranno = new javax.swing.JTextField();
        txtorderdate = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtcustomername = new javax.swing.JTextField();
        btnback = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnrefresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(150, 114, 89));

        jLabel7.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(56, 34, 15));
        jLabel7.setText("Welcome From Admin Panel");

        jLabel8.setFont(new java.awt.Font("Serif", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(56, 34, 15));
        jLabel8.setText("You can now modify customer's cart  from this ivory Cafe");

        TA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "Customer Name", "Item Name", "Item Price", "Quantity", "Total Price", "OrderDate", "Transcation No"
            }
        ));
        jScrollPane1.setViewportView(TA);

        jLabel2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Customer ID");

        jLabel4.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TransactionNo");

        jLabel6.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Order Date");

        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Customer Name");

        btnback.setText("BACK");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("/Users/hsuyeemon/Desktop/Final project zip/images/logo.png")); // NOI18N

        btnrefresh.setText("REFRESH");
        btnrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(312, 312, 312)
                        .addComponent(jLabel8))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(135, 135, 135))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1231, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(txtcustomerid, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(txtorderdate, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(txttranno, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addComponent(btnsearch)
                                .addGap(30, 30, 30)
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(txtcustomername, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(41, 41, 41)
                        .addComponent(btnrefresh)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnback)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(221, 221, 221)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txttranno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(txtcustomername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addGap(67, 67, 67)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtcustomerid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtorderdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnsearch)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnrefresh)
                                .addComponent(btnback)))))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                .addGap(53, 53, 53))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        DefaultTableModel m = (DefaultTableModel) TA.getModel();
        m.setRowCount(0);
        if (txtcustomerid.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
             String sql = "SELECT m.customerid, c.customername, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo "
                + "FROM mycart m "
                + "JOIN item i ON m.itemid = i.itemid "
                + "JOIN customer c ON m.customerid = c.customerid "
                + "WHERE m.customerid = '" + txtcustomerid.getText() + "'";

                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                     row[0] = rs.getString("customerid");
                    row[1]=rs.getString("customername");
                    row[2] = rs.getString("itemname");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("quantity");
                    row[5] = rs.getString("totalprice");
                    row[6] = rs.getString("datetime");
                    row[7] = rs.getString("tranNo");

                    m.addRow(row);
                    txtcustomerid.setText("");

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert existing id number to view order history!","Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else if (txttranno.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
              String sql = "SELECT m.customerid, c.customername, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo " +
             "FROM mycart m " +
             "JOIN item i ON m.itemid = i.itemid " +
             "JOIN customer c ON m.customerid = c.customerid " +
             "WHERE m.tranNo = '"+txttranno.getText()+"'";

                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("customerid");
                    row[1]=rs.getString("customername");
                    row[2] = rs.getString("itemname");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("quantity");
                    row[5] = rs.getString("totalprice");
                    row[6] = rs.getString("datetime");
                    row[7] = rs.getString("tranNo");
                    m.addRow(row);
                    txttranno.setText("");
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert correct transNo to view order history!","Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else if (txtorderdate.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
               String sql = "SELECT m.customerid, c.customername, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo " +
             "FROM mycart m " +
             "JOIN item i ON m.itemid = i.itemid " +
             "JOIN customer c ON m.customerid = c.customerid " +
             "WHERE m.datetime LIKE '%" + txtorderdate.getText() + "%'";


                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("customerid");
                    row[1]=rs.getString("customername");
                    row[2] = rs.getString("itemname");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("quantity");
                    row[5] = rs.getString("totalprice");
                    row[6] = rs.getString("datetime");
                    row[7] = rs.getString("tranNo");
                    m.addRow(row);
                    txtorderdate.setText("");
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert correct orderdate to view order history!","Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
         else if (txtcustomername.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
             String sql = "SELECT m.customerid, c.customername, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo " +
             "FROM mycart m " +
             "JOIN item i ON m.itemid = i.itemid " +
             "JOIN customer c ON m.customerid = c.customerid " +
             "WHERE c.customername LIKE '%" + txtcustomername.getText() + "%'";

                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("customerid");
                    row[1]=rs.getString("customername");
                    row[2] = rs.getString("itemname");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("quantity");
                    row[5] = rs.getString("totalprice");
                    row[6] = rs.getString("datetime");
                    row[7] = rs.getString("tranNo");
                    m.addRow(row);
                    txtcustomername.setText("");
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert correct customer name to view order history!","Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Search Error","Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
        admin_welcome a=new admin_welcome();
        a.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrefreshActionPerformed
        display();
    }//GEN-LAST:event_btnrefreshActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_m_cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_m_cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_m_cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_m_cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_m_cart().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TA;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnrefresh;
    private javax.swing.JButton btnsearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtcustomerid;
    private javax.swing.JTextField txtcustomername;
    private javax.swing.JTextField txtorderdate;
    private javax.swing.JTextField txttranno;
    // End of variables declaration//GEN-END:variables
}
