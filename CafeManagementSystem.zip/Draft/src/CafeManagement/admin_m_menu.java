/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CafeManagement;

import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class admin_m_menu extends javax.swing.JFrame {

    ResultSet rs ;
    Connection conn ;
    Statement stmt;
    String url = "jdbc:mysql://localhost:3306/cafe";
    String Driver = "com.mysql.cj.jdbc.Driver";
    String password = "mavismon";
    String username = "root";
    
    String s;
    String newPathForDb;
    Object[] row = new Object[6];
    
    
    public admin_m_menu() {
        initComponents();
        Auto();
        Display();
    }

public void Auto() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe", "root", "mavismon");
            Statement s = conn.createStatement();

            rs = s.executeQuery("select Max(itemid) from item");
            rs.next();

            rs.getString("Max(itemid)");

            if (rs.getString("Max(itemid)") == null) {
                txtitemid.setText("I0001");
            } else {
                Long id = Long.parseLong(rs.getString("Max(itemid)").substring(2, rs.getString("Max(itemid)").length()));
                id++;
                txtitemid.setText("I" + String.format("%04d", id));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }
    
private ImageIcon ResizeImage(String imagePath) {
    int imageX = 150;
    int imageY = 150;
    ImageIcon myImage = new ImageIcon(imagePath);
    Image img = myImage.getImage();
    Image newImage = img.getScaledInstance(imageX, imageY, Image.SCALE_SMOOTH);
    ImageIcon resizedImage = new ImageIcon(newImage);
    return resizedImage;
}

    public void Display() {
        try {
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from item");
            DefaultTableModel m = (DefaultTableModel) TA.getModel();
            m.setRowCount(0);
            while (rs.next()) {
                row[0] = rs.getString("itemid");
                row[1] = rs.getString("itemname");
                row[2] = rs.getString("itemcategory");
                row[3] = rs.getString("itemprice");
                row[4] = rs.getString("image");
                row[5]=rs.getString("stock");
                m.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TA = new javax.swing.JTable();
        photo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtitemname = new javax.swing.JTextField();
        txtitemcat = new javax.swing.JTextField();
        txtitemid = new javax.swing.JTextField();
        txtitemprice = new javax.swing.JTextField();
        btninsert = new javax.swing.JButton();
        btnbrowse = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btnsearch = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnback = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtstocks = new javax.swing.JTextField();
        btnrefresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(150, 114, 89));

        TA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item_id", "Item_name", "Item_category", "item_price", "image", "stocks"
            }
        ));
        TA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TA);

        photo.setBackground(new java.awt.Color(0, 0, 0));
        photo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(56, 34, 15));
        jLabel1.setText("Item ID");

        jLabel2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(56, 34, 15));
        jLabel2.setText("Item Name");

        jLabel3.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(56, 34, 15));
        jLabel3.setText("Item Category");

        jLabel4.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(56, 34, 15));
        jLabel4.setText("Item Price");

        txtitemid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemidActionPerformed(evt);
            }
        });

        btninsert.setText("Insert");
        btninsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninsertActionPerformed(evt);
            }
        });

        btnbrowse.setText("Browse");
        btnbrowse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbrowseActionPerformed(evt);
            }
        });

        btnupdate.setText("Update");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(56, 34, 15));
        jLabel5.setText("Welcome From Admin Panel");

        btnback.setText("Back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(56, 34, 15));
        jLabel6.setText("You can now modify menu tables ");

        jLabel7.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel7.setText("Photo");

        jLabel8.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(56, 34, 15));
        jLabel8.setText("Stocks");

        btnrefresh.setText("Refresh");
        btnrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(205, 205, 205)
                .addComponent(jLabel6)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 729, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtitemcat)
                                    .addComponent(txtitemprice)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(43, 43, 43))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtitemid)
                                    .addComponent(txtitemname)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtstocks))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                        .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnbrowse, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                    .addComponent(btninsert, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnsearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnupdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnback, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnrefresh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(48, 48, 48)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnbrowse, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(43, 43, 43))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtitemid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btninsert))
                                .addGap(39, 39, 39)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtitemname, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnsearch))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtitemcat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(btnupdate))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtitemprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(btnrefresh))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtstocks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnback)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 38, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btninsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninsertActionPerformed
    try
        {

            if (txtitemid.getText().isEmpty() || txtitemname.getText().isEmpty() || txtitemcat.getText().isEmpty() || txtitemprice.getText().isEmpty() || txtstocks.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all the required fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe", "root", "mavismon");
                Statement stmt = conn.createStatement();

                String sql = "insert into item values('" + txtitemid.getText() + "','" + txtitemname.getText() + "','" + txtitemcat.getText() + "','" + txtitemprice.getText() + "','" + s + "','" + txtstocks.getText() + "')";
                System.out.println("sql check " + sql);
                stmt.execute(sql);
                Display();
                JOptionPane.showMessageDialog(this, "insert successfully", "Correct", JOptionPane.WARNING_MESSAGE);

                txtitemid.setText("");
                txtitemname.setText("");
                txtitemcat.setText("");
                txtitemprice.setText("");
                txtstocks.setText("");

                photo.setText("");
                photo.setIcon(null);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }



    }//GEN-LAST:event_btninsertActionPerformed

    private void btnbrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbrowseActionPerformed
      newPathForDb="";
        photo.setText("");
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg","gif","png");
        fileChooser.addChoosableFileFilter(filter);
        int result = fileChooser.showSaveDialog(this);
        if(result == JFileChooser.APPROVE_OPTION){
            File selectedFile = fileChooser.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            System.out.println("insert image path "+path);
            photo.setIcon(ResizeImage(path));
            s = path;
         
            System.out.println("newPathForDb "+newPathForDb);
        }
        else if(result == JFileChooser.CANCEL_OPTION){
            System.out.println("No Data");
        }
    }//GEN-LAST:event_btnbrowseActionPerformed

    private void TAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TAMouseClicked
                               
    DefaultTableModel m = (DefaultTableModel)TA.getModel();
    int i = TA.getSelectedRow();
    txtitemid.setText(m.getValueAt(i, 0).toString());
    txtitemname.setText(m.getValueAt(i, 1).toString());
    txtitemcat.setText(m.getValueAt(i, 2).toString());
    txtitemprice.setText(m.getValueAt(i, 3).toString());
    txtstocks.setText(m.getValueAt(i, 5).toString());
    newPathForDb = m.getValueAt(i, 4).toString();

    ImageIcon imageIcon = ResizeImage(newPathForDb);
    photo.setIcon(imageIcon);


    }//GEN-LAST:event_TAMouseClicked

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed

   DefaultTableModel m = (DefaultTableModel) TA.getModel();
    int selectedRow = TA.getSelectedRow();
    if (selectedRow >= 0) {
    try {
        String sql = "update item set itemid='" + txtitemid.getText() + "', itemname='" + txtitemname.getText() + "', itemcategory='" + txtitemcat.getText() + "', itemprice='" + txtitemprice.getText() + "',stock='"+txtstocks.getText()+"' where itemid='" + txtitemid.getText() + "'";

        PreparedStatement pstmt = conn.prepareStatement(sql);
        System.out.print("error");
        int rowsUpdated = pstmt.executeUpdate();

        if (rowsUpdated > 0) {
           JOptionPane.showMessageDialog(this,"Update data success","Correct",JOptionPane.WARNING_MESSAGE);
 
            m.setValueAt(txtitemname.getText(), selectedRow, 1);
            m.setValueAt(txtitemcat.getText(), selectedRow, 2);
            m.setValueAt(txtitemprice.getText(), selectedRow, 3);
            m.setValueAt(txtstocks.getText(), selectedRow, 5);
        } else {
            JOptionPane.showMessageDialog(this, "Update failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        txtitemid.setText("");
        txtitemname.setText("");
        txtitemcat.setText("");
        txtitemprice.setText("");
        txtstocks.setText("");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
} else {
    JOptionPane.showMessageDialog(this, "Update Error!", "Error", JOptionPane.ERROR_MESSAGE);
}
   


    }//GEN-LAST:event_btnupdateActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
     DefaultTableModel m = (DefaultTableModel) TA.getModel();
        m.setRowCount(0);
        if (txtitemid.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                String sql = "Select * from item where itemid ='" + txtitemid.getText() + "' ";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("itemid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemcategory");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("image");
                row[5]=rs.getString("stock");
                    m.addRow(row);
                    txtitemid.setText("");

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(null, "Search data not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

        } else if (txtitemname.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                String sql = "Select * from item where itemname ='" + txtitemname.getText() + "' ";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("itemid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemcategory");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("image");
                    row[5]=rs.getString("stock");
                    m.addRow(row);

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(null, "Search data not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                txtitemname.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else if (txtitemcat.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                String sql = "Select * from item where itemcategory ='" + txtitemcat.getText() + "' ";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("itemid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemcategory");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("image");
                    row[5]=rs.getString("stock");
                    m.addRow(row);

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(null, "Search data not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                txtitemcat.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else if (txtitemprice.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                String sql = "Select * from item where itemprice ='" + txtitemprice.getText() + "' ";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("itemid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemcategory");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("image");
                    row[5]=rs.getString("stock");
                    m.addRow(row);

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(null, "Search data not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                txtitemprice.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else if (txtstocks.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                String sql = "Select * from item where stock ='" + txtstocks.getText() + "' ";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("itemid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemcategory");
                    row[3] = rs.getString("itemprice");
                    row[4] = rs.getString("image");
                    row[5]=rs.getString("stock");
                    m.addRow(row);

                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(null, "Search data not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                txtstocks.setText("");

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Search error!!", "Error", JOptionPane.ERROR_MESSAGE);
            Display();
        }
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
    admin_welcome a=new admin_welcome();
    a.setVisible(true);
    this.setVisible(false);
    }//GEN-LAST:event_btnbackActionPerformed

    private void txtitemidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtitemidActionPerformed

    private void btnrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrefreshActionPerformed
       Auto();
        Display();
    }//GEN-LAST:event_btnrefreshActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_m_menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_m_menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_m_menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_m_menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_m_menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TA;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnbrowse;
    private javax.swing.JButton btninsert;
    private javax.swing.JButton btnrefresh;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel photo;
    private javax.swing.JTextField txtitemcat;
    private javax.swing.JTextField txtitemid;
    private javax.swing.JTextField txtitemname;
    private javax.swing.JTextField txtitemprice;
    private javax.swing.JTextField txtstocks;
    // End of variables declaration//GEN-END:variables
}
