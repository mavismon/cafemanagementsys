/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CafeManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import java.sql.*;
import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author hsuyeemon
 */
public class admin_viewalldata extends javax.swing.JFrame {
    int columnCount=0;
    String[]st=new String[15];
    Object []row=new Object[100];
    String columnName="";
    ArrayList<String> cNameList = new ArrayList<String>();
    String Firstcolumn="";
    ResultSet rs=null;
    Connection conn=null;
    Statement stmt=null;
    
        
        String url = "jdbc:mysql://localhost:3306/cafe";
        String driver = "com.mysql.cj.jdbc.Driver";
        String username = "root";
        String password = "mavismon";
    public admin_viewalldata() {
        initComponents();
         try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe","root","mavismon");
                    DatabaseMetaData dbmd=(DatabaseMetaData) conn.getMetaData();
                    String[] types ={"TABLE"};
                    rs = dbmd.getTables("cafe", null, "%", types);
                    while(rs.next())
                    {
                        cmbtname.addItem(rs.getString("TABLE_NAME"));
                    }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
    }
 public void Table() {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe", "root", "mavismon");
            String sql = "select * from cafe." + cmbtname.getSelectedItem() + "";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            ResultSetMetaData resultSetMetaData=rs.getMetaData();
            columnCount = resultSetMetaData.getColumnCount();
            TA.setModel(DbUtils.resultSetToTableModel(rs));
            columnName=TA.getColumnName(0);
             for (int j = 0; j < columnCount; j++) {
                cNameList.add(TA.getColumnName(j));
                
            }
               System.out.println("column name list check "+Arrays.toString(cNameList.toArray()));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

    }
     private void insert() {

        try {
            DefaultTableModel model = (DefaultTableModel) TA.getModel();
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe", "root", "mavismon");
            stmt = conn.createStatement();
            String sql = "";
            if (columnCount == 2) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "')";
            } else if (columnCount == 3) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "')";
            } else if (columnCount == 4) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "')";
            } else if (columnCount == 5) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "')";
            } else if (columnCount == 6) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "','" + st[5] + "')";
            } else if (columnCount == 7) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "','" + st[5] + "',"
                                                                                 + "'" + st[6] + "')";
            } else if (columnCount == 8) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "','" + st[5] + "',"
                                                                                 + "'" + st[6] + "','" + st[7] + "')";
            } else if (columnCount == 9) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "','" + st[5] + "',"
                                                                                 + "'" + st[6] + "','" + st[7] + "','" + st[8] + "')";
            } else if (columnCount == 10) {
                sql = "insert into cafe." + cmbtname.getSelectedItem() + " values('" + st[0] + "','" + st[1] + "','" + st[2] + "',"
                                                                                 + "'" + st[3] + "','" + st[4] + "','" + st[5] + "',"
                                                                                 + "'" + st[6] + "','" + st[7] + "','" + st[8] + "',"
                                                                                 + "'" + st[9] + "')";
            }
            stmt.execute(sql);
            JOptionPane.showMessageDialog(this, "Add data success","Correct",JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

 /* private void update(){
      try{
            DefaultTableModel model = (DefaultTableModel) TA.getModel();
            Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe","root","mavismon");
            stmt = conn.createStatement();
            String sql = "";
            int index = TA.getSelectedRow();
            String aId = model.getValueAt(index,0).toString();
            if(columnCount == 2){
                  sql = "update cafe."+cmbtname.getSelectedItem()+" set "+cNameList.get(0)+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"'"
                                                                                                       + " where "+columnName+"='"+aId+"'";
               }else if(columnCount == 3){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                                                  + ""+cNameList.get(2)+"='"+st[2]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 4){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                   + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 5){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"' "
                                 + "where "+columnName+"='"+aId+"'";
               }else if(columnCount == 6){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 7){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 8){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"' "
                           + "where "+columnName+"='"+aId+"'";
               }else if(columnCount == 9){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"',"
                                 + ""+cNameList.get(8)+"='"+st[8]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 10){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"',"
                                 + ""+cNameList.get(8)+"='"+st[8]+"',"+cNameList.get(9)+"='"+st[9]+"' where "+columnName+"='"+aId+"'";
               }
               System.out.println("update query check "+sql);
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(this,"Update data success","Correct",JOptionPane.WARNING_MESSAGE);
            TA.clearSelection();
            
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
  }*/
     
      private void update(){
      try{
            DefaultTableModel model = (DefaultTableModel) TA.getModel();
            Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe","root","mavismon");
            stmt = conn.createStatement();
            String sql = "";
            int index = TA.getSelectedRow();
            String aId = model.getValueAt(index,0).toString();
            if(columnCount == 2){
                  sql = "update cafe."+cmbtname.getSelectedItem()+" set "+cNameList.get(0)+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"'"
                                                                                                       + " where "+columnName+"='"+aId+"'";
               }else if(columnCount == 3){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                                                  + ""+cNameList.get(2)+"='"+st[2]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 4){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                   + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 5){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"' "
                                 + "where "+columnName+"='"+aId+"'";
               }else if(columnCount == 6){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 7){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 8){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"' "
                           + "where "+columnName+"='"+aId+"'";
               }else if(columnCount == 9){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"',"
                                 + ""+cNameList.get(8)+"='"+st[8]+"' where "+columnName+"='"+aId+"'";
               }else if(columnCount == 10){
                   sql = "update cafe."+cmbtname.getSelectedItem()+" set "+columnName+"='"+st[0]+"',"+cNameList.get(1)+"='"+st[1]+"',"
                                 + ""+cNameList.get(2)+"='"+st[2]+"',"+cNameList.get(3)+"='"+st[3]+"',"+cNameList.get(4)+"='"+st[4]+"',"
                                 + ""+cNameList.get(5)+"='"+st[5]+"',"+cNameList.get(6)+"='"+st[6]+"',"+cNameList.get(7)+"='"+st[7]+"',"
                                 + ""+cNameList.get(8)+"='"+st[8]+"',"+cNameList.get(9)+"='"+st[9]+"' where "+columnName+"='"+aId+"'";
               }
               System.out.println("update query check "+sql);
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(this,"Update data success","Correct",JOptionPane.WARNING_MESSAGE);
            TA.clearSelection();
            
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
  }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TA = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        cmbtname = new javax.swing.JComboBox<>();
        btnaddrow = new javax.swing.JButton();
        btninsert = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btnback = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(150, 114, 89));

        TA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(TA);

        jLabel1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Table :");

        cmbtname.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        cmbtname.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbtnameItemStateChanged(evt);
            }
        });
        cmbtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtnameActionPerformed(evt);
            }
        });

        btnaddrow.setText("ADD ROW");
        btnaddrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddrowActionPerformed(evt);
            }
        });

        btninsert.setText("INSERT");
        btninsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninsertActionPerformed(evt);
            }
        });

        btnupdate.setText("UPDATE");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        btndelete.setText("DELETE");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });

        btnback.setText("BACK");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(56, 34, 15));
        jLabel7.setText("Welcome From Admin Panel");

        jLabel8.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(56, 34, 15));
        jLabel8.setText("You can now modify all information from this ivory Cafe");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(309, 309, 309)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbtname, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1051, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addGap(35, 35, 35)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnaddrow, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                                        .addComponent(btninsert, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btndelete, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnback, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(220, 220, 220)
                        .addComponent(jLabel8))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel7)
                .addGap(28, 28, 28)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnaddrow)
                        .addGap(52, 52, 52)
                        .addComponent(btninsert)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnupdate)
                        .addGap(52, 52, 52)
                        .addComponent(btndelete)
                        .addGap(46, 46, 46)
                        .addComponent(btnback))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbtnameItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbtnameItemStateChanged
        Table();
    }//GEN-LAST:event_cmbtnameItemStateChanged

    private void cmbtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbtnameActionPerformed

    private void btnaddrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddrowActionPerformed
        DefaultTableModel md = (DefaultTableModel) TA.getModel();
        String[] row = new String[columnCount];
        md.addRow(row);
    }//GEN-LAST:event_btnaddrowActionPerformed

    private void btninsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninsertActionPerformed
        int i = TA.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) TA.getModel();
        if (columnCount == 2) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
        }
        if (columnCount == 3) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
        }
        if (columnCount == 4) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
        }
        if (columnCount == 5) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
        }
        if (columnCount == 6) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
            st[5] = model.getValueAt(i, 5).toString();
        }
        if (columnCount == 7) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
            st[5] = model.getValueAt(i, 5).toString();
            st[6] = model.getValueAt(i, 6).toString();
        }
        if (columnCount == 8) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
            st[5] = model.getValueAt(i, 5).toString();
            st[6] = model.getValueAt(i, 6).toString();
            st[7] = model.getValueAt(i, 7).toString();
        }
        if (columnCount == 9) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
            st[5] = model.getValueAt(i, 5).toString();
            st[6] = model.getValueAt(i, 6).toString();
            st[7] = model.getValueAt(i, 7).toString();
            st[8] = model.getValueAt(i, 8).toString();
        }
        if (columnCount == 10) {
            st[0] = model.getValueAt(i, 0).toString();
            st[1] = model.getValueAt(i, 1).toString();
            st[2] = model.getValueAt(i, 2).toString();
            st[3] = model.getValueAt(i, 3).toString();
            st[4] = model.getValueAt(i, 4).toString();
            st[5] = model.getValueAt(i, 5).toString();
            st[6] = model.getValueAt(i, 6).toString();
            st[7] = model.getValueAt(i, 7).toString();
            st[8] = model.getValueAt(i, 8).toString();
            st[9] = model.getValueAt(i, 9).toString();
        }

        insert();
    }//GEN-LAST:event_btninsertActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        int i=TA.getSelectedRow();

        DefaultTableModel model = (DefaultTableModel) TA.getModel();
        if(columnCount == 2){
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
        }
        if(columnCount == 3)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
        }
        if(columnCount == 4)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
        }
        if(columnCount == 5)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
        }
        if(columnCount == 6)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
            st[5]=model.getValueAt(i,5).toString();
        }
        if(columnCount == 7)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
            st[5]=model.getValueAt(i,5).toString();
            st[6]=model.getValueAt(i,6).toString();
        }
        if(columnCount == 8)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
            st[5]=model.getValueAt(i,5).toString();
            st[6]=model.getValueAt(i,6).toString();
            st[7]=model.getValueAt(i,7).toString();
        }
        if(columnCount == 9)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
            st[5]=model.getValueAt(i,5).toString();
            st[6]=model.getValueAt(i,6).toString();
            st[7]=model.getValueAt(i,7).toString();
            st[8]=model.getValueAt(i,8).toString();
        }
        if(columnCount == 10)
        {
            st[0]=model.getValueAt(i,0).toString();
            st[1]=model.getValueAt(i,1).toString();
            st[2]=model.getValueAt(i,2).toString();
            st[3]=model.getValueAt(i,3).toString();
            st[4]=model.getValueAt(i,4).toString();
            st[5]=model.getValueAt(i,5).toString();
            st[6]=model.getValueAt(i,6).toString();
            st[7]=model.getValueAt(i,7).toString();
            st[8]=model.getValueAt(i,8).toString();
            st[9]=model.getValueAt(i,9).toString();
        }

        update();
    }//GEN-LAST:event_btnupdateActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
       DefaultTableModel m = (DefaultTableModel) TA.getModel();
        int i = TA.getSelectedRow();
        String delete = m.getValueAt(i, 0).toString();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cafe", "root", "mavismon");
            stmt = conn.createStatement();

            String sql = "DELETE FROM cafe. " + cmbtname.getSelectedItem() + " WHERE " + columnName + " = '" + delete + "' ";
            stmt.executeUpdate(sql);
            JOptionPane.showMessageDialog(this, "Delete data success","Correct",JOptionPane.WARNING_MESSAGE);
            m.removeRow(i);
            TA.clearSelection();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
    admin_welcome a=new admin_welcome();
    a.setVisible(true);
    this.setVisible(false);
    }//GEN-LAST:event_btnbackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_viewalldata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_viewalldata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_viewalldata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_viewalldata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_viewalldata().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TA;
    private javax.swing.JButton btnaddrow;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btndelete;
    private javax.swing.JButton btninsert;
    private javax.swing.JButton btnupdate;
    private javax.swing.JComboBox<String> cmbtname;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
