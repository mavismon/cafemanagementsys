/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CafeManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hsuyeemon
 */
public final class customer_orderhistory extends javax.swing.JFrame {

    ResultSet rs = null;
    Connection conn = null;
    Statement stmt = null;
    Object[] row = new Object[10];
    String url = "jdbc:mysql://localhost:3306/cafe";
    String Driver = "com.mysql.cj.jdbc.Driver";
    String password = "mavismon";
    String username = "root";

    private String id;

    public customer_orderhistory() {
        initComponents();
        System.out.println("default construcotr run");
        display();

    }

    public customer_orderhistory(String userid) {
        initComponents();
        this.id = userid;
        customerid.setText(id);
        customerid.setVisible(true);
      
        display();

    }

    public void display() {
     //   System.out.println("aaaaaaaaa=" + "Step2" + customerid.getText());
        try {
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement();
            // rs = stmt.executeQuery("");
            String sql = "SELECT m.customerid, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo "
                    + "FROM mycart m "
                    + "JOIN item i ON m.itemid = i.itemid "
                    + "WHERE m.customerid = '" + customerid.getText() + "'";
        //    System.out.println("aaaaaaaaa=" + sql);
            rs = stmt.executeQuery(sql);
            DefaultTableModel m = (DefaultTableModel) TA.getModel();
            m.setRowCount(0);
            while (rs.next()) {
                row[0] = rs.getString("customerid");
                row[1] = rs.getString("itemname");
                row[2] = rs.getString("itemprice");
                row[3] = rs.getString("quantity");
                row[4] = rs.getString("totalprice");
                row[5] = rs.getString("datetime");
                row[6] = rs.getString("tranNo");
                m.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TA = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnsearch = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txttranno = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtorderdate = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        customerid = new javax.swing.JLabel();
        btnback = new javax.swing.JButton();
        btnlogout = new javax.swing.JButton();
        btnrefresh = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(150, 114, 89));

        TA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "Item Name", "Item Price", "Quantity", "Total Price", "OrderDate", "Transcation No"
            }
        ));
        jScrollPane1.setViewportView(TA);

        jLabel1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Here is your all order history");

        jLabel2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Customer ID");

        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("If you remember the transcation No, you can search here to know the exact order");

        jLabel4.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TransactionNo");

        jLabel5.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("If you remember the order date, you can search by date to know the exact order");

        jLabel6.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Order Date");

        jLabel10.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(56, 34, 15));
        jLabel10.setText("WELCOME CUSTOMERS");

        jLabel9.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(56, 34, 15));
        jLabel9.setText("You can now search your order history by following..");

        customerid.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        customerid.setForeground(new java.awt.Color(255, 255, 255));

        btnback.setText("BACK");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });

        btnlogout.setText("LOG OUT");
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });

        btnrefresh.setText("Refresh");
        btnrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrefreshActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(32, 32, 32)
                                .addComponent(customerid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtorderdate, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(txttranno, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(29, 29, 29)
                        .addComponent(btnsearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnrefresh))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(31, 31, 31)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1210, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(btnback)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnlogout)
                            .addGap(25, 25, 25)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(475, 475, 475)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(349, 349, 349)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(81, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(customerid, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(txttranno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(txtorderdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnsearch)
                            .addComponent(btnrefresh))))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnback)
                    .addComponent(btnlogout))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
      /*  DefaultTableModel m = (DefaultTableModel) TA.getModel();
        m.setRowCount(0);
        if (txttranno.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                 String sql = "SELECT m.customerid, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo "
                + "FROM mycart m "
                + "JOIN item i ON m.itemid = i.itemid "
                + "JOIN customer c ON m.customerid = c.customerid "
                + "WHERE m.tranNo = '" + txttranno.getText() + "' "
                + "AND m.customerid = '" + customerid + "'";
                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("customerid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemprice");
                    row[3] = rs.getString("quantity");
                    row[4] = rs.getString("totalprice");
                    row[5] = rs.getString("datetime");
                    row[6] = rs.getString("tranNo");
                    m.addRow(row);
                    txttranno.setText("");
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert your correct transNo to view order history!","ERROR",JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else if (txtorderdate.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();
                 String sql = "SELECT m.customerid, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo "
                + "FROM mycart m "
                + "JOIN item i ON m.itemid = i.itemid "
                + "JOIN customer c ON m.customerid = c.customerid "
                + "WHERE m.datetime = '" + txtorderdate.getText() + "' "
                + "AND m.customerid = '" + customerid + "'";

                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    row[0] = rs.getString("customerid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemprice");
                    row[3] = rs.getString("quantity");
                    row[4] = rs.getString("totalprice");
                    row[5] = rs.getString("datetime");
                    row[6] = rs.getString("tranNo");
                    m.addRow(row);
                    txttranno.setText("");
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "Please insert your correct orderdate to view order history!","ERROR",JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Search Error","ERROR",JOptionPane.ERROR_MESSAGE);
        }*/

        DefaultTableModel m = (DefaultTableModel) TA.getModel();
        m.setRowCount(0);

        String customerID = customerid.getText();

        if (txttranno.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();

                String tranNo = txttranno.getText();
             
                String sql = "SELECT c.customerid, i.itemname, i.itemprice, mc.quantity, mc.totalprice, mc.datetime, mc.tranNo\n"
                        + "FROM mycart mc\n"
                        + "JOIN customer c ON c.customerid = mc.customerid\n"
                        + "JOIN item i ON i.itemid = mc.itemid\n"
                        + "WHERE c.customerid = '" + customerID + "'"
                        + "  AND mc.tranNo = '" + tranNo + "'  ";

                System.out.println("bbbbb=" + sql);

                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    Object[] row = new Object[7];
                    row[0] = rs.getString("customerid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemprice");
                    row[3] = rs.getString("quantity");
                    row[4] = rs.getString("totalprice");
                    row[5] = rs.getString("datetime");
                    row[6] = rs.getString("tranNo");
                    m.addRow(row);
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "No matching records found for the given transaction number.", "No Results", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else if (txtorderdate.getText().length() > 0) {
            try {
                conn = DriverManager.getConnection(url, username, password);
                stmt = conn.createStatement();

                String orderDate = txtorderdate.getText();
               
                
               String sql = "SELECT m.customerid, i.itemname, i.itemprice, m.quantity, m.totalprice, m.datetime, m.tranNo "
           + "FROM mycart m "
           + "JOIN item i ON m.itemid = i.itemid "
           + "JOIN customer c ON m.customerid = c.customerid "
           + "WHERE m.datetime LIKE '%" + orderDate + "%' "
           + "AND m.customerid = '" + customerID + "'";



                rs = stmt.executeQuery(sql);
                int count = 0;
                while (rs.next()) {
                    count++;
                    Object[] row = new Object[7];
                    row[0] = rs.getString("customerid");
                    row[1] = rs.getString("itemname");
                    row[2] = rs.getString("itemprice");
                    row[3] = rs.getString("quantity");
                    row[4] = rs.getString("totalprice");
                    row[5] = rs.getString("datetime");
                    row[6] = rs.getString("tranNo");
                    m.addRow(row);
                }
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "No matching records found for the given order date.", "No Results", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please provide either transaction number or order date.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
    String userid=customerid.getText();
    customer_viewallmenu c=new customer_viewallmenu(userid);
    c.setVisible(true);
    this.hide();
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlogoutActionPerformed
    System.exit(0);
    
    }//GEN-LAST:event_btnlogoutActionPerformed

    private void btnrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrefreshActionPerformed
        customerid.setText(id);
        customerid.setVisible(true);
        display();
    }//GEN-LAST:event_btnrefreshActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer_orderhistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer_orderhistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer_orderhistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer_orderhistory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer_orderhistory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TA;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnlogout;
    private javax.swing.JButton btnrefresh;
    private javax.swing.JButton btnsearch;
    private javax.swing.JLabel customerid;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtorderdate;
    private javax.swing.JTextField txttranno;
    // End of variables declaration//GEN-END:variables
}
