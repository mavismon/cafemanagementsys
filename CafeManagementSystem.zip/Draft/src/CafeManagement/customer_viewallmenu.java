/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CafeManagement;

import java.awt.Image;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.Arrays;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class customer_viewallmenu extends javax.swing.JFrame {

    ResultSet rs = null;
    Connection conn = null;
    Statement stmt = null;
    Object[] row = new Object[6];
    String url = "jdbc:mysql://localhost:3306/cafe";
    String Driver = "com.mysql.cj.jdbc.Driver";
    String password = "mavismon";
    String username = "root";

    int grandTotal = 0;
    String newPathForDb;

    List<String> idList = new ArrayList();
    private String userid;

    public customer_viewallmenu() {
        initComponents();
//       getTransactionNumber();
        itemid.setVisible(false);
        displayA();
        getTransactionNumber();
        transno.setVisible(false);
        // lblstock.setVisible(false);
        currentdatetime();

    }

    customer_viewallmenu(String i) {

        this.userid = i;
        initComponents();
        customerid.setText(userid);
        itemid.setVisible(false);
        displayA();
        getTransactionNumber();
        transno.setVisible(false);
        lblstock.setVisible(false);
        currentdatetime();

    }

    public void currentdatetime() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        datetime.setText(dtf.format(now));
    }

    public void displayA() {
        idList.clear();

        Object[] row = new Object[10];

        try {
            conn = DriverManager.getConnection(url, username, password);
            stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from item");
            DefaultTableModel model = (DefaultTableModel) TA.getModel();
            model.setRowCount(0);
            while (rs.next()) {
                row[0] = rs.getString("itemid");
                row[1] = rs.getString("itemname");

                row[2] = rs.getString("itemcategory");

                row[3] = rs.getString("itemprice");
                row[4] = rs.getString("stock");
                row[5] = rs.getString("image");
                model.addRow(row);
                idList.add(rs.getObject(1).toString());
            }

            int columnIndex1 = 4; // Index of the first column you want to hide
            int columnIndex2 = 5; // Index of the second column you want to hide

            JTable table = TA; // Replace 'TA' with the variable name of your JTable

// Get the TableColumnModel of the table
            TableColumnModel columnModel = table.getColumnModel();

// Hide the first column
            TableColumn column1 = columnModel.getColumn(columnIndex1);
            column1.setMinWidth(0);
            column1.setMaxWidth(0);

// Hide the second column
            TableColumn column2 = columnModel.getColumn(columnIndex2);
            column2.setMinWidth(0);
            column2.setMaxWidth(0);

// Hide the column headers
            JTableHeader header = table.getTableHeader();
            TableColumnModel headerColumnModel = header.getColumnModel();
            TableColumn headerColumn1 = headerColumnModel.getColumn(columnIndex1);
            TableColumn headerColumn2 = headerColumnModel.getColumn(columnIndex2);
            headerColumn1.setMaxWidth(0);
            headerColumn2.setMaxWidth(0);

// Repaint the table to reflect the changes
            table.repaint();

            System.out.println("all id " + Arrays.toString(idList.toArray()));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

    }

    public void getTransactionNumber() {
        String sDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int count = 0;
        String transNo;

        try {
            conn = DriverManager.getConnection(url, username, password);

            String query = "SELECT tranNo FROM mycart WHERE tranNo LIKE ? ORDER BY refno DESC";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, sDate + "%");

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                transNo = resultSet.getString("tranNo");
                count = Integer.parseInt(transNo.substring(8, 12));
            }

            String newTransactionNumber = sDate + String.format("%04d", count + 1);
            transno.setText(newTransactionNumber);

            resultSet.close();
            preparedStatement.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);

        }

    }

    public void fetchCartData() {

        int i = 0;
        double total = 0;

        try {
            conn = DriverManager.getConnection(url, username, password);
            String query = "SELECT i.itemid, i.itemname, m.quantity, i.itemprice, m.totalprice FROM mycart m JOIN item i ON m.itemid = i.itemid WHERE m.tranNo LIKE '" + transno.getText() + "'";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            //preparedStatement.setString(1, transno.getText());

            ResultSet resultSet = preparedStatement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) TB.getModel();

            // Clear the table model before populating it with new data
            model.setRowCount(0);

            while (resultSet.next()) {
                i++;
                total += resultSet.getDouble("totalprice");
                model.addRow(new Object[]{
                    i,
                    resultSet.getString("itemid"),
                    resultSet.getString("itemname"),
                    resultSet.getString("quantity"),
                    resultSet.getString("itemprice"),
                    resultSet.getString("totalprice")
                });
            }
            // lbltotal.setText(String.format("#,##0.00",total));
            lbltotal.setText(String.valueOf(total));
            resultSet.close();
            preparedStatement.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private ImageIcon ResizeImage(String imagePath) {
        int imageX = 180;
        int imageY = 187;
        ImageIcon myImage = new ImageIcon(imagePath);
        Image img = myImage.getImage();
        Image newImage = img.getScaledInstance(imageX, imageY, Image.SCALE_SMOOTH);
        ImageIcon resizedImage = new ImageIcon(newImage);
        return resizedImage;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        itemid1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        photo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TA = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        txtitemid = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        qty = new javax.swing.JSpinner();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtitemprice = new javax.swing.JTextField();
        btnaddtocart = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TB = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        qtyspinner = new javax.swing.JSpinner();
        btnupdateqty = new javax.swing.JButton();
        btnplaceorder = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        itemid = new javax.swing.JLabel();
        transno = new javax.swing.JLabel();
        lbltotal = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        datetime = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnviewhistory = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        lblstock = new javax.swing.JLabel();
        customerid = new javax.swing.JLabel();
        btnremoveorder = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblstock1 = new javax.swing.JLabel();

        itemid1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        itemid1.setForeground(new java.awt.Color(255, 255, 255));
        itemid1.setText("ItemID");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(150, 114, 89));

        photo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        TA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item_Id", "Item_Name", "Item_Category", "Item_Price", "stock", "imagepath"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TAMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                TAMouseEntered(evt);
            }
        });
        jScrollPane1.setViewportView(TA);
        if (TA.getColumnModel().getColumnCount() > 0) {
            TA.getColumnModel().getColumn(4).setResizable(false);
            TA.getColumnModel().getColumn(5).setResizable(false);
        }

        jLabel4.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Item ID");

        txtitemid.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtitemidInputMethodTextChanged(evt);
            }
        });
        txtitemid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtitemidActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Quantity");

        qty.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                qtyStateChanged(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Customer ID");

        jLabel6.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Item Price");

        btnaddtocart.setText("Add to cart");
        btnaddtocart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddtocartActionPerformed(evt);
            }
        });

        TB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Item ID", "Item Name", "Quantity", "Price", "Total Price"
            }
        ));
        TB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TBMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TB);

        jLabel7.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantity");

        qtyspinner.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                qtyspinnerStateChanged(evt);
            }
        });

        btnupdateqty.setText("Update quantity");
        btnupdateqty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateqtyActionPerformed(evt);
            }
        });

        btnplaceorder.setText("Place Order");
        btnplaceorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplaceorderActionPerformed(evt);
            }
        });

        itemid.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        itemid.setForeground(new java.awt.Color(255, 255, 255));
        itemid.setText("ItemID");

        transno.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        transno.setForeground(new java.awt.Color(255, 255, 255));
        transno.setText("Transno");

        lbltotal.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        lbltotal.setForeground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Order date and time");

        datetime.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        datetime.setForeground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(56, 34, 15));
        jLabel9.setText("You can now select items and order here!");

        jLabel10.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(56, 34, 15));
        jLabel10.setText("WELCOME CUSTOMERS");

        btnviewhistory.setText("View Order History");
        btnviewhistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnviewhistoryActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Final Price");

        lblstock.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        lblstock.setForeground(new java.awt.Color(255, 255, 255));
        lblstock.setText("Stock");

        customerid.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        customerid.setForeground(new java.awt.Color(255, 255, 255));

        btnremoveorder.setText("Remove Order");
        btnremoveorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnremoveorderActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(56, 34, 15));
        jLabel12.setText("Remark: Only Cash On Delivery is available ! Thanks !");

        jLabel3.setIcon(new javax.swing.ImageIcon("/Users/hsuyeemon/Desktop/Final project zip/images/logo.png")); // NOI18N

        lblstock1.setFont(new java.awt.Font("Serif", 1, 18)); // NOI18N
        lblstock1.setForeground(new java.awt.Color(255, 255, 255));
        lblstock1.setText("Photo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(btnaddtocart)
                                .addGap(30, 30, 30)
                                .addComponent(lblstock))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jLabel2)))
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addComponent(jLabel4)))
                                .addGap(41, 41, 41)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(customerid, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtitemprice, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                                            .addComponent(txtitemid)))
                                    .addComponent(qty, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(89, 89, 89)
                                        .addComponent(lblstock1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(35, 35, 35)
                                        .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 601, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(164, 164, 164)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(qtyspinner, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(22, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnplaceorder, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnupdateqty, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnremoveorder, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnviewhistory, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 469, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(129, 129, 129)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(351, 351, 351))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(datetime, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(itemid)
                .addGap(130, 130, 130)
                .addComponent(transno, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(182, 182, 182)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(datetime, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(itemid)
                                .addComponent(transno)))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtitemid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel11)
                                        .addComponent(jLabel4)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(customerid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(34, 34, 34)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel7)
                                            .addComponent(qtyspinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(39, 39, 39)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel2))
                                        .addGap(34, 34, 34)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel6)
                                            .addComponent(txtitemprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(35, 35, 35)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btnaddtocart)
                                            .addComponent(lblstock)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btnupdateqty)
                                            .addComponent(btnremoveorder))
                                        .addGap(27, 27, 27)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btnplaceorder)
                                            .addComponent(btnviewhistory))
                                        .addGap(53, 53, 53))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(lblstock1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(photo, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TAMouseClicked

        int selectedIndex = TA.getSelectedRow();
        int quantity = (int) qty.getValue();

        DefaultTableModel model = (DefaultTableModel) TA.getModel();

        double price = Double.parseDouble(model.getValueAt(selectedIndex, 3).toString());
        double totalprice = quantity * price;
        if (selectedIndex >= 0) {
            txtitemid.setText(model.getValueAt(selectedIndex, 0).toString());
        }
        txtitemprice.setText(model.getValueAt(selectedIndex, 3).toString());
        lblstock.setText(model.getValueAt(selectedIndex, 4).toString());

        String imagePath = model.getValueAt(selectedIndex, 5).toString(); // Assuming the value is the image path as a String
        ImageIcon imageIcon = ResizeImage(imagePath);
        photo.setIcon(imageIcon);


    }//GEN-LAST:event_TAMouseClicked

    private void btnaddtocartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddtocartActionPerformed

        int quantity = (int) qty.getValue();
        int selectedIndex = TA.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) TA.getModel();
        double price = Double.parseDouble(model.getValueAt(selectedIndex, 3).toString());
        double totalprice = quantity * price;

        try {
            int stockQuantity = Integer.parseInt(model.getValueAt(selectedIndex, 4).toString());

            if (stockQuantity == 0) {
                JOptionPane.showMessageDialog(this, "Item is out of stock.","ERROR",JOptionPane.ERROR_MESSAGE);
            } else if (quantity > stockQuantity) {
                JOptionPane.showMessageDialog(this, "Insufficient stock for the selected quantity.","ERROR",JOptionPane.ERROR_MESSAGE);
            } else if (quantity == 0) {
                JOptionPane.showMessageDialog(this, "Please increase the quantity","ERROR",JOptionPane.ERROR_MESSAGE);
            } else {
                String sql = "INSERT INTO mycart (itemid, customerid, quantity, price, totalprice, tranNo, datetime) VALUES "
                        + "('" + txtitemid.getText() + "','" + customerid.getText() + "' , '" + qty.getValue() + "', '" + txtitemprice.getText() + "', '" + totalprice + "','" + transno.getText() + "', '" + datetime.getText() + "')";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.execute();
                fetchCartData();
                JOptionPane.showMessageDialog(this, "Added to your order lists","Correct",JOptionPane.WARNING_MESSAGE);
                pstmt.close();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }


    }//GEN-LAST:event_btnaddtocartActionPerformed

    private void btnupdateqtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateqtyActionPerformed

        //  SpinnerNumberModel spinnerModel = new SpinnerNumberModel(0, 0, Integer.MAX_VALUE, 1);
        //  qtyspinner = new JSpinner(spinnerModel);
        int selectedIndex = TB.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) TB.getModel();
        double price = Double.parseDouble(model.getValueAt(selectedIndex, 4).toString());
        int quantity = (int) qtyspinner.getValue();
      
        if (selectedIndex >= 0) {
            try {
                String qty = "update mycart set quantity='" + qtyspinner.getValue() + "' where itemid='" + itemid.getText() + "'";
                PreparedStatement pstmt = conn.prepareStatement(qty);
                pstmt.executeUpdate();
                fetchCartData();

                JOptionPane.showMessageDialog(this,"Update quantity success","Correct",JOptionPane.WARNING_MESSAGE);
                pstmt.close();
                qtyspinner.setValue(0);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e);
            }
        }

        try {

            double totalPrice = quantity * price;
            String sql = "update mycart set totalprice='" + totalPrice + "' where itemid='" + itemid.getText() + "'";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
            fetchCartData();

            pstmt.close();

            model.setValueAt(quantity, selectedIndex, 3);
            model.setValueAt(totalPrice, selectedIndex, 5);

            double finalTotal = 0;
            for (int i = 0; i < model.getRowCount(); i++) {
                double itemTotal = Double.parseDouble(model.getValueAt(i, 5).toString());
                finalTotal += itemTotal;
            }

            lbltotal.setText(String.format("%.2f", finalTotal));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }


    }//GEN-LAST:event_btnupdateqtyActionPerformed

    private void TBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TBMouseClicked

        int selectedIndex = TB.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel) TB.getModel();

        if (selectedIndex >= 0) {
            // Get the itemid from the selected row
            String itemId = model.getValueAt(selectedIndex, 1).toString();
            itemid.setText(itemId);

            // Get the quantity value from the selected row
            Object value = model.getValueAt(selectedIndex, 3);
            if (value != null) {
                int quantity = 0;
                if (!value.toString().isEmpty()) {
                    quantity = Integer.parseInt(value.toString());
                }

                // Set the value of the spinner
                qtyspinner.setValue(quantity);
            }
        }


    }//GEN-LAST:event_TBMouseClicked

    private void btnplaceorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplaceorderActionPerformed

        DefaultTableModel model = (DefaultTableModel) TB.getModel();
        int rowCount = model.getRowCount();

        try {
            for (int i = 0; i < rowCount; i++) {
                int quantityOrdered = Integer.parseInt(model.getValueAt(i, 3).toString());
                String itemID = model.getValueAt(i, 1).toString();

                // Retrieve the current stock quantity from the database
                PreparedStatement stockQuery = conn.prepareStatement("SELECT stock FROM item WHERE itemid = ?");
                stockQuery.setString(1, itemID);
                ResultSet stockResult = stockQuery.executeQuery();

                if (stockResult.next()) {
                    int currentStock = stockResult.getInt("stock");

                    // Calculate the remaining stock after the order
                    int remainingStock = currentStock - quantityOrdered;

                    if (remainingStock < 0) {
                        // Handle case where the ordered quantity exceeds the available stock
                        JOptionPane.showMessageDialog(this, "Insufficient stock for item ID: "  + itemID);
                    } else {
                        // Update the stock in the database
                        PreparedStatement stockUpdate = conn.prepareStatement("UPDATE item SET stock = ? WHERE itemid = ?");
                        stockUpdate.setInt(1, remainingStock);
                        stockUpdate.setString(2, itemID);
                        stockUpdate.executeUpdate();
                    }
                }
            }
             JOptionPane.showMessageDialog(this,"Your order is placed!\nThe delivery is on its way","Correct",JOptionPane.WARNING_MESSAGE);
            

            customer_finalpage c = new customer_finalpage();
            c.setVisible(true);
            this.setVisible(false);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }


    }//GEN-LAST:event_btnplaceorderActionPerformed

    private void btnviewhistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnviewhistoryActionPerformed
        //   String i=customerid.getText();
        System.out.println("data check=============" + userid);
        customer_orderhistory c = new customer_orderhistory(userid);
        c.setVisible(true);
        this.hide();
    }//GEN-LAST:event_btnviewhistoryActionPerformed

    private void txtitemidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtitemidActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_txtitemidActionPerformed

    private void txtitemidInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtitemidInputMethodTextChanged
        // TODO add your handling code here:
        String transNo;
        int stocknum = 0;
        try {
            conn = DriverManager.getConnection(url, username, password);
            String query = "SELECT stock FROM item WHERE itemid = '" + txtitemid.getText() + "' ";
            PreparedStatement preparedStatement = conn.prepareStatement(query);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                stocknum = resultSet.getInt("stock");
            }
            lblstock.setText(Integer.toString(stocknum));
            resultSet.close();
            preparedStatement.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }//GEN-LAST:event_txtitemidInputMethodTextChanged

    private void TAMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TAMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_TAMouseEntered

    private void btnremoveorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnremoveorderActionPerformed
        DefaultTableModel model = (DefaultTableModel) TB.getModel();
        int rowCount = model.getRowCount();

        try {
            conn = DriverManager.getConnection(url, username, password);
            String query = "DELETE FROM mycart WHERE tranNo = '" + transno.getText() + "' ";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            // preparedStatement.setString(1, transno.getText()); // Bind the transaction number parameter

            int rowsAffected = preparedStatement.executeUpdate();
            

            if (rowsAffected > 0) {
                while (model.getRowCount() > 0) {
                    model.removeRow(0);
                }
                 JOptionPane.showMessageDialog(this,"Remove order successfully","Correct",JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Only existing orders can remove!\n Please select items to order", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }


    }//GEN-LAST:event_btnremoveorderActionPerformed

    private void qtyStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_qtyStateChanged
        /*   int selectedValue = (int) qty.getValue();
                if (selectedValue < 0) {
                    qty.setValue(0);
                }*/
    }//GEN-LAST:event_qtyStateChanged

    private void qtyspinnerStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_qtyspinnerStateChanged
        /*  int selectedValue = (int) qtyspinner.getValue();
                if (selectedValue < 0) {
                    qtyspinner.setValue(0);
                }*/
    }//GEN-LAST:event_qtyspinnerStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer_viewallmenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer_viewallmenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer_viewallmenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer_viewallmenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer_viewallmenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TA;
    private javax.swing.JTable TB;
    private javax.swing.JButton btnaddtocart;
    private javax.swing.JButton btnplaceorder;
    private javax.swing.JButton btnremoveorder;
    private javax.swing.JButton btnupdateqty;
    private javax.swing.JButton btnviewhistory;
    private javax.swing.JLabel customerid;
    private javax.swing.JLabel datetime;
    private javax.swing.JLabel itemid;
    private javax.swing.JLabel itemid1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblstock;
    private javax.swing.JLabel lblstock1;
    private javax.swing.JLabel lbltotal;
    private javax.swing.JLabel photo;
    private javax.swing.JSpinner qty;
    private javax.swing.JSpinner qtyspinner;
    private javax.swing.JLabel transno;
    private javax.swing.JTextField txtitemid;
    private javax.swing.JTextField txtitemprice;
    // End of variables declaration//GEN-END:variables
}
